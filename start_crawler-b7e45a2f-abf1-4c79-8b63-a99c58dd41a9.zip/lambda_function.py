import json
import boto3

glue = boto3.client('glue')
lam = boto3.client('lambda')
def lambda_handler(event, context):
    glue.start_crawler(Name=event['crawler_name'])
    payload = {'Glue_job':'READY_TO_RUN'}
    lam.invovoke(function_name= 'check_crawler', 
    InvocationType='Event',
    Payload=json.dumps(Payload)
    )