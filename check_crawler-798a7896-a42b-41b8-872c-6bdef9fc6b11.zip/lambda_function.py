import json
import time
import boto3

glue = boto3.client("glue")
lam = boto3.client("lambda")
def lambda_handler(event, context):
    print("Event data",event)
    resp = glue.get_crawler(
        Name="new_crawler"
    )
    
    if (resp['Crawler']['State'] != "READY"):
        print("Crawler is running")
        time.sleep(15)
        lam.invoke(
            FunctionName=context.function_name,
            InvocationType="Event"
        )
    elif (resp['Crawler']['LastCrawl']['Status'] == "SUCCEEDED" and resp['Crawler']['State'] == "READY"):
        if ("Glue_job" in event):           
            if (event['Glue_job'] == "READY_TO_RUN"):
                return lam.invoke(
                    FunctionName="start_job",
                    InvocationType="Event"
                )
            else:                    
                payload = {"crawler_name":"new_crawler"}
                lam.invoke(
                    FunctionName="start_crawler",
                    InvocationType="Event",
                    Payload=json.dumps(payload)
                )
                print("In side else Crawler started")
        else:                    
            payload = {"crawler_name":"new_crawler"}
            lam.invoke(
                FunctionName="start_crawler",
                InvocationType="Event",
                Payload=json.dumps(payload)
            )
            print("Crawler started")
    elif (resp['Crawler']['LastCrawl']['Status'] == "FAILED"):
        lam.invoke(
            FunctionName=context.function_name,
            InvocationType="Event"
        )